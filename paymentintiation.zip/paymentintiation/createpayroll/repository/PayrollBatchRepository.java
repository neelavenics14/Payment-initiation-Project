package com.scb.paymentintiation.createpayroll.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.scb.paymentintiation.createpayroll.model.PayrollBatch;

@Repository
public interface PayrollBatchRepository extends JpaRepository<PayrollBatch, Long> {
}