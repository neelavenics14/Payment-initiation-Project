package com.scb.paymentintiation.createpayroll.service;




import com.scb.paymentintiation.createpayroll.model.PayrollBatch;
import com.scb.paymentintiation.createpayroll.repository.PayrollBatchRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PayrollService {

    private final PayrollBatchRepository repository;

    public PayrollService(PayrollBatchRepository repository) {
        this.repository = repository;
    }

    public PayrollBatch saveBatch(PayrollBatch batch) {
        return repository.save(batch);
    }

    public List<PayrollBatch> getAllBatches() {
        return repository.findAll();
    }

    public PayrollBatch getBatchById(Long id) {
        return repository.findById(id).orElse(null);
    }
}