package com.scb.paymentintiation.createpayroll.model;

import jakarta.persistence.Embeddable;

@Embeddable
public class Payment {
    private String payeeDetails;
    private String payeeName;
    private String accountNumber;
    private String reference;
    private String amount;

    public String getPayeeDetails() { return payeeDetails; }
    public void setPayeeDetails(String payeeDetails) { this.payeeDetails = payeeDetails; }

    public String getPayeeName() { return payeeName; }
    public void setPayeeName(String payeeName) { this.payeeName = payeeName; }

    public String getAccountNumber() { return accountNumber; }
    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }

    public String getReference() { return reference; }
    public void setReference(String reference) { this.reference = reference; }

    public String getAmount() { return amount; }
    public void setAmount(String amount) { this.amount = amount; }
}