package com.scb.paymentintiation.createpayroll.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "payroll_batches")
public class PayrollBatch {

    @Id
    private Long id;

    @Embedded
    private Instruction instruction;

    @ElementCollection
    @CollectionTable(name = "payments", joinColumns = @JoinColumn(name = "batch_id"))
    private List<Payment> payments;

    private String status;
    private String createdAt;
    private String updatedAt;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Instruction getInstruction() { return instruction; }
    public void setInstruction(Instruction instruction) { this.instruction = instruction; }

    public List<Payment> getPayments() { return payments; }
    public void setPayments(List<Payment> payments) { this.payments = payments; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

    public String getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(String updatedAt) { this.updatedAt = updatedAt; }
}