package com.scb.paymentintiation.createpayroll.controller;


import com.scb.paymentintiation.createpayroll.model.PayrollBatch;
import com.scb.paymentintiation.createpayroll.service.PayrollService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/payroll")
@CrossOrigin(origins = "http://localhost:3000") // React frontend
public class PayrollController {

    private final PayrollService service;

    public PayrollController(PayrollService service) {
        this.service = service;
    }

    @PostMapping("/batch")
    public PayrollBatch saveOrSubmitBatch(@RequestBody PayrollBatch batch) {
        return service.saveBatch(batch);
    }

    @GetMapping("/batch")
    public List<PayrollBatch> getAllBatches() {
        return service.getAllBatches();
    }

    @GetMapping("/batch/{id}")
    public PayrollBatch getBatchById(@PathVariable Long id) {
        return service.getBatchById(id);
    }
}